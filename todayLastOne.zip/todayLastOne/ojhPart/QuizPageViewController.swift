//
//  QuizPageViewController.swift
//  ojhPart
//
//  Created by MacBook on 2018. 8. 7..
//  Copyright © 2018년 MacBook. All rights reserved.
//

import UIKit

class QuizPageViewController: UIPageViewController, UIPageViewControllerDataSource {

    lazy var viewControllerList:[UIViewController] = {
        let sb = UIStoryboard(name: "Main",bundle: nil)
        var vc1 = sb.instantiateViewController(withIdentifier: "quizVC1")
        var vc2 = sb.instantiateViewController(withIdentifier: "quizVC2")
        var vc3 = sb.instantiateViewController(withIdentifier: "quizVC3")
            
        return [vc1,vc2,vc3]
    }()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        if let firstViewController = viewControllerList.first {
            self.setViewControllers([firstViewController], direction: .forward, animated: true, completion: nil)
        }
        if let thirdViewController = viewControllerList.last {
            self.setViewControllers([thirdViewController], direction: .reverse, animated: true, completion: nil)
        }
    }
    // 전의 화면으로
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
            
        guard let beforeFuncIndex = viewControllerList.index(of: viewController) else { return nil }
            
        let previousIndex = beforeFuncIndex - 1
        print("뒤로가는 Func \n\npreviousIndex의 값은 \(previousIndex)")
        
        guard previousIndex >= 0 else { return nil } //previousIndex 가 <0 라면 리턴 닐... 함수 끝 > 이렇게 해서 첫화면부터 뒤로가는건 불가능 ㅇㅇ
        
        
        //아래꺼 복붙하긴 했는데 되려나?
        guard previousIndex != 0 else { //  previousIndex가 0이라면 밑의 명령어들을 실행한다.
            indexM.vcIndex -= 1
            print(indexM.vcIndex)
            return viewControllerList.last
        }
        
        
        guard viewControllerList.count > previousIndex else { return nil } // previousIndex 3보다 크다면 함수 끝 3보다 작다면 밑에
        indexM.vcIndex -= 1
        print("뒤로갈경우 \(beforeFuncIndex)")
        print("뒤로갈경우 인덱스.비씨는 \(indexM.vcIndex)")
        return viewControllerList[previousIndex]
    }
    
    // 후의 화면으로
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        guard let afterFuncIndex = viewControllerList.index(of: viewController) else { return nil } //뷰컨트롤러리스트 인덱스는 제일처음 0인가?
                print("\nviewControllerList.index는 \(viewControllerList.index(of: viewController)).")
                print("afterFuncIndex는 \(afterFuncIndex)")
                print("indexM.vcIndex는 \(indexM.vcIndex)")
        
        
        let nextIndex = afterFuncIndex + 1
        //유저가 마지막 페이지 컨트롤러에 도착, 오른쪽으로 swipe하면 처음 페이지로 돌아갈 수 있음.
                print("nextindex는 \(nextIndex)")
        
        guard viewControllerList.count != nextIndex else { //뷰컨트롤러리스트 카운트(3)과 넥스트 인덱스 값이 같다면 {} 실행하거라 아니면 아래의 함수
            indexM.vcIndex += 1
            print("위 guard 실행)  indexM.vcindex는 \(indexM.vcIndex)")
            return viewControllerList.first
        }
        
        guard viewControllerList.count > nextIndex else { return nil } //뷰컨트롤러리스트 카운트(3)보다 넥스트인덱스가 크다면 함수 끝, 작다면 아래 명령어 실행
        indexM.vcIndex += 1
        print("아래 guard 실행)  indexM.vcindex는 \(indexM.vcIndex)")
        return viewControllerList[nextIndex]
    

    }
    
//배열의 끝자리 수를 인식해서 그 값에 도달하면 아래꺼를 실행하지 않도록 해야지 않을까?


}
