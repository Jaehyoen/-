//
//  QuizTeduriViewController.swift
//  ojhPart
//
//  Created by MacBook on 2018. 8. 7..
//  Copyright © 2018년 MacBook. All rights reserved.
//

import UIKit

class QuizTeduriViewController: UIViewController {

    @IBOutlet weak var modeSelectOutlet: UISegmentedControl!
    @IBOutlet weak var basicModeView: UIView!
    @IBOutlet weak var flipModeView: UIView!
    
    @IBAction func modeSelect(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 1 {
            basicModeView.alpha = 1
            flipModeView.alpha = 0
        } else {
            basicModeView.alpha = 0
            flipModeView.alpha = 1
        }
    }
    //그냥 더미데이터 여기에 넣었음.
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
