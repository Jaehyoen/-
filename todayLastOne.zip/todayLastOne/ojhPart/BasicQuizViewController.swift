//
//  WordTableViewController.swift
//  ojhPart
//
//  Created by MacBook on 2018. 8. 4..
//  Copyright © 2018년 MacBook. All rights reserved.
//

import UIKit

class BasicQuizViewController: UITableViewController {
    
    @IBOutlet weak var chapterLabel: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var answerLabel: UITextField!
    @IBOutlet weak var answercheckLabel: UILabel!
    @IBOutlet weak var odapButton: UIButton!
    @IBOutlet weak var checkButton: UIButton!
    @IBOutlet weak var importantOutletButton: UIButton!
   
    var cellNumber :Int = 3
    var theUnit : OneUnit = OneUnit()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let dummyword1 = dummywords() // 여기 밑 부분들은 나중에 값을 받기때문에 생각하지말고 있자.
//        dummyword1.key = "사과"
//        dummyword1.explanation = "apple"
//        dummyword1.odapCount = false
//        dummyword1.important = false

        let dummyword1 = dummywords(key: "1", explanation: "apple")
        let dummyword2 = dummywords(key: "2", explanation: "바나나")
        let dummyword3 = dummywords(key: "3", explanation: "Cherry")
        let dummyword4 = dummywords(key: "4", explanation: "포도")
        let dummyword5 = dummywords(key: "5", explanation: "BREAD")
        let dummyword6 = dummywords(key: "6", explanation: "잠")
        let dummyword7 = dummywords(key: "7", explanation: "anger")
        
        theUnit.alldummywords = [dummyword1, dummyword2, dummyword3, dummyword4, dummyword5, dummyword6, dummyword7]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        questionLabel.text = theUnit.alldummywords[indexM.vcIndex].key
        answercheckLabel.text = theUnit.alldummywords[indexM.vcIndex].explanation
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

        // Dispose of any resources that can be recreated.
    }
    @IBAction func Check(_ sender: Any) {
        cellNumber = 4
        self.tableView.reloadData()
        
        var answerLabelLower = answerLabel.text?.lowercased()
        var answerCheckLabelLower = answercheckLabel.text?.lowercased()
        
        if answerLabelLower == answerCheckLabelLower {
            answercheckLabel.textColor = UIColor.green
            odapButton.isHidden = true
        } else {return}
        checkButton.isEnabled = false
    }
    var flag = true
    @IBAction func importantButton(_ sender: AnyObject) {
        if flag == true {
            importantOutletButton.setImage(UIImage(named: "star"), for: .normal)
            
            flag = false
        } else {
            importantOutletButton.setImage(UIImage(named: "blankstar"), for: .normal)
            flag = true
        }
        
    }
    
    var odapflag = true
    @IBAction func increaseOdap(_ sender: Any) {
        if odapflag == true {
            
        }
        
        //오답 횟수 증가할 것
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return cellNumber
    }
}


