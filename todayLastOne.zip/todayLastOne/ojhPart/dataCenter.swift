//
//  dataCenter.swift
//  ojhPart
//
//  Created by MacBook on 2018. 8. 9..
//  Copyright © 2018년 MacBook. All rights reserved.
//

import Foundation

let chapterList : ChapterList = ChapterList()
let indexM : IndexM = IndexM()

class IndexM {
    var vcIndex: Int
    init() {
        self.vcIndex = 0
    }
}

class ChapterList {
    var chapters: [String]
    init () {
        chapters = ["지수와 로그", "유리수와 무리수", "집합"]
    }
}

class OneUnit {
    var alldummywords: [dummywords]
    init() {
        self.alldummywords = []
    }
    
}

class dummywords {
    var key:String
    var explanation:String
    var odapCount:Bool
    var important:Bool
    
    init (key:String, explanation:String) {
        self.key = key
        self.explanation = explanation
        self.odapCount = false
        self.important = false
    }
}


