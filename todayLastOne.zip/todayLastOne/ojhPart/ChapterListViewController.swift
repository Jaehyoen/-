//
//  ChapterListViewController.swift
//  ojhPart
//
//  Created by MacBook on 2018. 8. 4..
//  Copyright © 2018년 MacBook. All rights reserved.
//

import UIKit

//주의) 클래스는 챕터네임셀.
class ChapterNameCell: UITableViewCell {
    
    @IBOutlet weak var chapterName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
 
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}


//클래스변경 챕터리스트뷰컨트롤러
class ChapterListViewController: UITableViewController {
    
    var chapterArray = chapterList.chapters
    
    override func viewDidLoad() {
        chapterArray.insert("랜덤식", at: 0)
        super.viewDidLoad()
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
 
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
 
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chapterArray.count
    }
 
 
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "chapterCell", for: indexPath)
        guard let myCell = cell as? ChapterNameCell else {
            return cell
        }
        myCell.chapterName.text = chapterArray[indexPath.row]
        return myCell
    }
}



