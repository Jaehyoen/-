//
//  QuizPageViewController.swift
//  ojhPart
//
//  Created by MacBook on 2018. 8. 7..
//  Copyright © 2018년 MacBook. All rights reserved.
//

import UIKit
    //가이드 페이지 총 3장, 이 함수는 3개의 가이드 페이지 뷰를 호출하기 위한 함수
    //3개의 가이드 페이지 뷰컨트롤러의 배열, identifiers는 순서대로 [quizVC1, quizVC2, quizVC3]
/*
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.index(of: viewController) else {
            return nil
        }
        
        let nextIndex = viewControllerIndex + 1
        let orderedViewControllersCount = orderedViewControllers.count
        
        //유저가 마지막 페이지 컨트롤러에 도착, 오른쪽으로 swipe하면 처음 페이지로 돌아갈 수 있음.
        guard orderedViewControllersCount != nextIndex else {
            return orderedViewControllers.first
        }
        
        guard orderedViewControllersCount > nextIndex else {
            return nil
        }
        
        return orderedViewControllers[nextIndex]
    }
    
  */
    class QuizPageViewController: UIPageViewController, UIPageViewControllerDataSource {
        
        lazy var viewControllerList:[UIViewController] = {
            let sb = UIStoryboard(name: "Main",bundle: nil)
            var vc1 = sb.instantiateViewController(withIdentifier: "quizVC1")
            var vc2 = sb.instantiateViewController(withIdentifier: "quizVC2")
            var vc3 = sb.instantiateViewController(withIdentifier: "quizVC3")
            
            return [vc1,vc2,vc3]
        }()
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            self.dataSource = self
            if let firstViewController = viewControllerList.first {
                self.setViewControllers([firstViewController], direction: .forward, animated: true, completion: nil)
            }
        }
        
        func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
            
            guard let vcIndex = viewControllerList.index(of: viewController) else {return nil}
            
            let previousIndex = vcIndex - 1
            guard previousIndex >= 0 else {return nil}
            guard viewControllerList.count > previousIndex else {return nil}
            
            return viewControllerList[previousIndex]
        }
        
        func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
            
            guard let vcIndex = viewControllerList.index(of: viewController) else {return nil}
            
            let nextIndex = vcIndex + 1
            
            let viewControllerListCount = viewControllerList.count
            
            //유저가 마지막 페이지 컨트롤러에 도착, 오른쪽으로 swipe하면 처음 페이지로 돌아갈 수 있음.
            guard viewControllerListCount != nextIndex else {return viewControllerList.first}
            
            guard viewControllerListCount > nextIndex else {return nil}
            
            return viewControllerList[nextIndex]
        }
       
        
        func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
            if !completed { return }
            DispatchQueue.main.async() {
                self.dataSource = nil
                self.dataSource = self
            }
        }
}



