//
//  ChapterListViewController.swift
//  ojhPart
//
//  Created by MacBook on 2018. 8. 4..
//  Copyright © 2018년 MacBook. All rights reserved.
//

import UIKit



 var chapterArray = ["랜덤식","1단원","2단원","3단원"]
 /* 해당 내용은 나중에 생성된 단원에서 랜덤식만 추가한 배열로
 데이터센터에서 항목을 들고와야함.
 
 var arr : Array<Int> = [1,2,3,4]
 arr.insert(5, at: 4)//[1,2,3,4,5]
 arr.insert(0, at: 0)//[0,1,2,3,4,5]
 */
 //랜덤식이면 어떻게 제공을 할지 생각을 해보자... 몇개의 퀴즈항목(모든단원 다 더하면 된다)이 있는지도 나타내줘야할듯.
 //단원도 마찬가지.
 
 
 
 class ChapterNameCell: UITableViewCell {
 
 @IBOutlet weak var chapterName: UILabel!
 
 
 override func awakeFromNib() {
 super.awakeFromNib()
 // Initialization code
 }
 
 override func setSelected(_ selected: Bool, animated: Bool) {
 super.setSelected(selected, animated: animated)
 
 // Configure the view for the selected state
 }
 
 }
 
 class ChapterListViewController: UITableViewController {
 
 override func viewDidLoad() {
 super.viewDidLoad()
 
 // Uncomment the following line to preserve selection between presentations
 // self.clearsSelectionOnViewWillAppear = false
 
 // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
 // self.navigationItem.rightBarButtonItem = self.editButtonItem
 }
 
 override func didReceiveMemoryWarning() {
 super.didReceiveMemoryWarning()
 // Dispose of any resources that can be recreated.
 }
 
 // MARK: - Table view data source
 
 override func numberOfSections(in tableView: UITableView) -> Int {
 // #warning Incomplete implementation, return the number of sections
 return 1
 }
 
 override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
 // #warning Incomplete implementation, return the number of rows
 return chapterArray.count
 }
 
 
 override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
 let cell = tableView.dequeueReusableCell(withIdentifier: "chapterCell", for: indexPath)
 guard let myCell = cell as? ChapterNameCell else {
 return cell
 }
 myCell.chapterName.text = chapterArray[indexPath.row]
 
 
 /* guard let myCell = cell as? TableViewCell else {
 return cell
 }
 
 myCell.myLabel.text = labelArray[indexPath.section]
 myCell.imageViewer.image = imageArray[indexPath.section]
 
 */
 
 // Configure the cell...
 
 return cell
 }
 
 
 /*
 // Override to support conditional editing of the table view.
 override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
 // Return false if you do not want the specified item to be editable.
 return true
 }
 */
 
 /*
 // Override to support editing the table view.
 override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
 if editingStyle == .delete {
 // Delete the row from the data source
 tableView.deleteRows(at: [indexPath], with: .fade)
 } else if editingStyle == .insert {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */
 
 /*
 // Override to support rearranging the table view.
 override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
 
 }
 */
 
 /*
 // Override to support conditional rearranging of the table view.
 override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
 // Return false if you do not want the item to be re-orderable.
 return true
 }
 */
 
 /*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
 // Get the new view controller using segue.destinationViewController.
 // Pass the selected object to the new view controller.
 }
 */
 
 }



