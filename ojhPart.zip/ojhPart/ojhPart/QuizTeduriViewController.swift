//
//  QuizTeduriViewController.swift
//  ojhPart
//
//  Created by MacBook on 2018. 8. 7..
//  Copyright © 2018년 MacBook. All rights reserved.
//

import UIKit

class QuizTeduriViewController: UIViewController {

    @IBOutlet weak var modeSelectOutlet: UISegmentedControl!
    @IBOutlet weak var basicModeView: UIView!
    @IBOutlet weak var flipModeView: UIView!
    
    @IBAction func modeSelect(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 1 {
            basicModeView.alpha = 1
            flipModeView.alpha = 0
        } else {
            basicModeView.alpha = 0
            flipModeView.alpha = 1
        }
    }
    /*
     @IBOutlet weak var basicView: UIView!
     @IBOutlet weak var flipView: UIView!
     @IBOutlet weak var modeOutlet: UISegmentedControl!
    
    @IBAction func modeSelect(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {basicView.alpha = 1
            flipView.alpha = 0
        } else {
            basicView.alpha = 0
            flipView.alpha = 1
        }
    }
     */
    
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
